import greenfoot.*;  // (World, Actor, GreenfootImage, and Greenfoot)

/**
 * This class defines a crab. Crabs live on the beach.
 * 
 * Version: 2
 * 
 * In this version, the crab walks around the beach more or less randomly.
 */
public class Crab extends Actor
{
    /** 
     * Act - do whatever the crab wants to do. This method is called whenever
     *  the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        turnAtEdge();
        randomTurn();       
        move(4);
        lookForWorm();
    }
    
    /**
     * Checks for worms, if the Crab finds a worm it will eat it. Otherwise it will do nothing.
     */
    public void lookForWorm()
    {
        if( isTouching(Worm.class) )
        {
            removeTouching(Worm.class);
            Greenfoot.playSound("slurp.wav");
        }
    }
    
    public void turnAtEdge()
    {
        if ( isAtEdge() ) 
        {
            turn(50);
        }
    }
    
    public void randomTurn()
    {
        if ( Greenfoot.getRandomNumber(100) < 10 ) 
        {
            turn( Greenfoot.getRandomNumber(90) -45 );
        }
    }
}